document.addEventListener('DOMContentLoaded', () => {
    const resultsContainer = document.getElementById('resultsContainer');
    const storedResults = localStorage.getItem('processedResults');

    if (storedResults) {
        resultsContainer.innerHTML = storedResults;
    } else {
        resultsContainer.innerHTML = '<p>No results to display.</p>';
    }
});
