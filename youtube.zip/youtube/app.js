document.getElementById('processBtn').addEventListener('click', async () => {
    const htmlTemplate = document.getElementById('htmlBlock').value;
    const dataFile = document.getElementById('dataFile').files[0];
    if (!dataFile) {
        alert('Please select a data file.');
        return;
    }

    const data = await readJsonFile(dataFile);
    let outputHtml = '';

    data.forEach(item => {
        // console.log(item.player);
        let processedHtml = htmlTemplate
            .replace(/&title&/g, item.title)
            .replace(/&link&/g, item.url)
            .replace(/&id&/g, item.videoId)
            .replace(/&iframe&/g, item.player);
        outputHtml += processedHtml;
    });
    // Save the processed HTML to local storage
    localStorage.setItem('processedResults', outputHtml);

    // Directly set the text content of the output element
    document.getElementById('codeBlock').textContent = outputHtml;

});

function readJsonFile(file) {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = event => resolve(JSON.parse(event.target.result));
        reader.onerror = error => reject(error);
        reader.readAsText(file);
    });
}

document.addEventListener('DOMContentLoaded', () => {
    // Initialize ClipboardJS
    new ClipboardJS('#copyButton');

    // Change button text on click to indicate success
    document.getElementById('copyButton').addEventListener('click', function () {
        this.textContent = '✅ Copied!';
        setTimeout(() => {
            this.textContent = '📋 Copy code';
        }, 2000);
    });
});




