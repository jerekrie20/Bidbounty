const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const readline = require('readline');
const fs = require('fs').promises;

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

const defualtKey = 'AIzaSyBn_j9UHacyKeVxMXj6gNxc2wwMamBaIZI';

function askQuestion(question) {
  return new Promise(resolve => rl.question(question, resolve));
}

async function fetchVideos(apiKey, playlistId) {
  const videos = [];
  let pageToken = '';

  do {
    const url = new URL('https://www.googleapis.com/youtube/v3/playlistItems');
    url.searchParams.set('part', 'snippet');
    url.searchParams.set('playlistId', playlistId);
    url.searchParams.set('maxResults', '50');
    url.searchParams.set('key', apiKey);
    if (pageToken) url.searchParams.set('pageToken', pageToken);

    const response = await fetch(url.href);
    const data = await response.json();

    if (response.status !== 200) {
      throw new Error(`API request failed with status ${response.status}: ${data.error.message}`);
    }

    for (const item of data.items) {
      const { title, resourceId } = item.snippet;
      const videoId = resourceId.videoId;
      videos.push({
        title,
        videoId,
        url: `https://www.youtube.com/watch?v=${videoId}`
      });
    }

    pageToken = data.nextPageToken || '';
  } while (pageToken);

  await fs.writeFile('playlist_videos.json', JSON.stringify(videos, null, 2));
  console.log(`Fetched ${videos.length} videos from the playlist and saved to playlist_videos.json`);
}


async function fetchChannelId(apiKey, query) {
  const url = new URL('https://www.googleapis.com/youtube/v3/channels');
  url.searchParams.set('part', 'id,snippet');
  url.searchParams.set('forUsername', query); // Try to find the channel by username first
  url.searchParams.set('key', apiKey);

  try {
    const response = await fetch(url.href);
    const data = await response.json();

    if (response.status !== 200) {
      throw new Error(`API request failed with status ${response.status}: ${data.error.message}`);
    }

    if (data.items && data.items.length > 0) {
      const channelId = data.items[0].id;
      console.log(`Channel ID for '${query}' is: ${channelId}`);
    } else {
      // If the channel is not found by username, try a search query instead
      console.log(`No channel found with username '${query}'. Trying a general search.`);
      const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
      searchUrl.searchParams.set('part', 'snippet');
      searchUrl.searchParams.set('q', query);
      searchUrl.searchParams.set('type', 'channel');
      searchUrl.searchParams.set('key', apiKey);

      const searchResponse = await fetch(searchUrl.href);
      const searchData = await searchResponse.json();

      if (searchResponse.status !== 200) {
        throw new Error(`Search request failed with status ${searchResponse.status}: ${searchData.error.message}`);
      }

      if (searchData.items && searchData.items.length > 0) {
        const searchChannelId = searchData.items[0].snippet.channelId;
        console.log(`Channel ID found by search for '${query}' is: ${searchChannelId}`);
      } else {
        console.log(`No channel found for the search query '${query}'.`);
      }
    }
  } catch (error) {
    console.error('Error fetching channel ID:', error);
  }
}


async function searchChannel(apiKey, channelId, options) {
  const videos = [];
  let pageToken = '';

  do {
    const url = new URL('https://www.googleapis.com/youtube/v3/search');
    url.searchParams.set('part', 'snippet');
    url.searchParams.set('channelId', channelId);
    url.searchParams.set('type', 'video');
    url.searchParams.set('order', 'date'); // Order by date if the timeframe is relevant
    url.searchParams.set('maxResults', '50');
    url.searchParams.set('key', apiKey);
    if (options.publishedAfter) url.searchParams.set('publishedAfter', options.publishedAfter);
    if (options.publishedBefore) url.searchParams.set('publishedBefore', options.publishedBefore); // If you want to set an end time for the search
    if (pageToken) url.searchParams.set('pageToken', pageToken);

    const response = await fetch(url.href);
    const data = await response.json();

    if (response.status !== 200) {
      throw new Error(`API request failed with status ${response.status}: ${data.error.message}`);
    }

    data.items.forEach(item => {
      const { title, publishedAt } = item.snippet;
      const videoId = item.id.videoId;
      videos.push({
        title,
        videoId,
        publishedAt,
        url: `https://www.youtube.com/watch?v=${videoId}`
      });
    });

    pageToken = data.nextPageToken || '';
  } while (pageToken);

  // Write the videos array to a JSON file
  await fs.writeFile('search_results.json', JSON.stringify(videos, null, 2));
  console.log(`Fetched ${videos.length} videos from channel ID ${channelId} within the specified timeframe and saved to search_results.json`);
}



async function main() {
  const apiKey = await askQuestion('Enter your API Key or press Enter to use the default: ');
  const task = await askQuestion('Choose an option:\n1. Videos from a Playlist\n2. Channel ID\n3. General Channel Search\n');

  switch (task) {
    case '1':
      const playlistId = await askQuestion('Enter the playlist ID: ');
      await fetchVideos(apiKey || defualtKey, playlistId);
      break;
    case '2':
      const query = await askQuestion('Enter the channel name, username, etc.: ');
      await fetchChannelId(apiKey || defualtKey, query);
      break;
    case '3':
      const channelId = await askQuestion('Enter the channel ID: ');
      const publishedAfter = await askQuestion('Enter the start date (e.g., 2024-01-01T00:00:00Z): ');
      const publishedBefore = await askQuestion('Enter the end date (optional, press Enter to skip): ');

      const options = {
        publishedAfter: publishedAfter,
        publishedBefore: publishedBefore || undefined  // Only set if a value was provided
      };

      await searchChannel(apiKey || defualtKey, channelId, options);
      break;
  }

  rl.close();
}

main().catch(error => {
  console.error('An error occurred:', error);
  rl.close();
});
