const fetch = (...args) => import('node-fetch').then(({default: fetch}) => fetch(...args));

import inquirer from 'inquirer';
import fs from 'fs/promises';
import {parse} from 'json2csv';

const QUOTA_LIMIT = 10000; // Default daily quota limit

const defualtKey = 'AIzaSyBn_j9UHacyKeVxMXj6gNxc2wwMamBaIZI';

async function updateQuotaUsage(newQuotaUsed) {
    const quotaFile = 'quotaUsage.json';
    let quotaInfo = {date: new Date().toISOString().slice(0, 10), usage: 0};

    try {
        const data = await fs.readFile(quotaFile, 'utf8');
        quotaInfo = JSON.parse(data);
    } catch (error) {
        // File does not exist, will be created with the write operation below
    }

    const today = new Date().toISOString().slice(0, 10);
    if (quotaInfo.date === today) {
        quotaInfo.usage += newQuotaUsed;
    } else {
        // If it's a new day, reset the usage
        quotaInfo.date = today;
        quotaInfo.usage = newQuotaUsed;
    }

    await fs.writeFile(quotaFile, JSON.stringify(quotaInfo, null, 2));
}


async function readQuotaUsage() {
    const quotaFile = 'quotaUsage.json';
    try {
        const data = await fs.readFile(quotaFile, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        // If the file doesn't exist or another error occurs, assume starting fresh
        return {date: new Date().toISOString().slice(0, 10), usage: 0};
    }
}


function askQuestion(question) {
    return new Promise(resolve => rl.question(question, resolve));
}

async function fetchVideos(apiKey, playlistId, formatChoice) {
    const quotaInfo = await readQuotaUsage();
    const today = new Date().toISOString().slice(0, 10);

    if (quotaInfo.date === today && quotaInfo.usage >= QUOTA_LIMIT) {
        console.warn('Approaching daily quota limit of 10,000. Please try again tomorrow.');
        return;
    }

    const videos = [];
    let pageToken = '';

    do {
        const url = new URL('https://www.googleapis.com/youtube/v3/playlistItems');
        url.searchParams.set('part', 'snippet');
        url.searchParams.set('playlistId', playlistId);
        url.searchParams.set('maxResults', '50');
        url.searchParams.set('key', apiKey);
        if (pageToken) url.searchParams.set('pageToken', pageToken);

        const response = await fetch(url.href);
        const data = await response.json();

        if (response.status !== 200) {
            throw new Error(`API request failed with status ${response.status}: ${data.error.message}`);
        }


        for (const item of data.items) {
            const videoId = item.snippet.resourceId.videoId;
            const videoDetailsUrl = new URL('https://www.googleapis.com/youtube/v3/videos');
            videoDetailsUrl.searchParams.set('part', 'snippet,player');
            videoDetailsUrl.searchParams.set('id', videoId);
            videoDetailsUrl.searchParams.set('key', apiKey);

            const videoResponse = await fetch(videoDetailsUrl.href);
            const videoData = await videoResponse.json();

            if (videoResponse.status !== 200) {
                console.error(`Video details request failed with status ${videoResponse.status}: ${videoData.error.message}`);
                continue; // Skip to the next video if the current one fails
            }

            // Assuming there's at least one item and it has player information
            if (videoData.items.length > 0 && videoData.items[0].player) {
                const player = videoData.items[0].player.embedHtml;

                videos.push({
                    title: item.snippet.title,
                    videoId,
                    url: `https://www.youtube.com/watch?v=${videoId}`,
                    player
                });
            }

            await updateQuotaUsage(1); // Increment quota usage for each request
        }


        await updateQuotaUsage(1); // Increment quota usage for each request
        pageToken = data.nextPageToken || '';
    } while (pageToken);

    //Order the videos by title
    videos.sort((a, b) => a.title.localeCompare(b.title));

    // Write the videos array to a JSON/CSV file
    if (formatChoice.format === 'CSV') {
        const csv = parse(videos); // Replace yourDataArray with the actual data array
        await fs.writeFile('output.csv', csv);
        console.log('Data saved as CSV');
    } else { // JSON is the default format
        await fs.writeFile('output.json', JSON.stringify(videos, null, 2)); // Replace yourDataArray with the actual data array
        console.log('Data saved as JSON');
    }
    console.log(`Fetched ${videos.length} videos from the playlist and saved to output file`);
}


async function fetchChannelId(apiKey, query) {
    const quotaInfo = await readQuotaUsage();
    const today = new Date().toISOString().slice(0, 10);

    if (quotaInfo.date === today && quotaInfo.usage >= QUOTA_LIMIT) {
        console.warn('Approaching daily quota limit of 10,000. Please try again tomorrow.');
        return;
    }
    const url = new URL('https://www.googleapis.com/youtube/v3/channels');
    url.searchParams.set('part', 'id,snippet');
    url.searchParams.set('forUsername', query); // Try to find the channel by username first
    url.searchParams.set('key', apiKey);

    try {
        const response = await fetch(url.href);
        const data = await response.json();

        if (response.status !== 200) {
            throw new Error(`API request failed with status ${response.status}: ${data.error.message}`);
        }

        if (data.items && data.items.length > 0) {
            await updateQuotaUsage(1); // Increment quota usage for each request
            const channelId = data.items[0].id;
            console.log(`Channel ID for '${query}' is: ${channelId}`);
        } else {
            // If the channel is not found by username, try a search query instead
            console.log(`No channel found with username '${query}'. Trying a general search.`);
            const searchUrl = new URL('https://www.googleapis.com/youtube/v3/search');
            searchUrl.searchParams.set('part', 'snippet');
            searchUrl.searchParams.set('q', query);
            searchUrl.searchParams.set('type', 'channel');
            searchUrl.searchParams.set('key', apiKey);

            const searchResponse = await fetch(searchUrl.href);
            const searchData = await searchResponse.json();

            if (searchResponse.status !== 200) {
                throw new Error(`Search request failed with status ${searchResponse.status}: ${searchData.error.message}`);
            }

            if (searchData.items && searchData.items.length > 0) {
                const searchChannelId = searchData.items[0].snippet.channelId;
                console.log(`Channel ID found by search for '${query}' is: ${searchChannelId}`);
            } else {
                console.log(`No channel found for the search query '${query}'.`);
            }
            await updateQuotaUsage(101); // Increment quota usage for each request
        }
        // Increment quota usage for each request
    } catch (error) {
        console.error('Error fetching channel ID:', error);
    }
}


async function searchChannel(apiKey, channelId, options, formatChoice) {
    const quotaInfo = await readQuotaUsage();
    const today = new Date().toISOString().slice(0, 10);

    if (quotaInfo.date === today && quotaInfo.usage >= QUOTA_LIMIT) {
        console.warn('Approaching daily quota limit of 10,000. Please try again tomorrow.');
        return;
    }

    const videos = [];
    let pageToken = '';

    do {
        const url = new URL('https://www.googleapis.com/youtube/v3/search');
        url.searchParams.set('part', 'snippet');
        url.searchParams.set('channelId', channelId);
        url.searchParams.set('type', 'video');
        url.searchParams.set('order', 'date'); // Order by date if the timeframe is relevant
        url.searchParams.set('maxResults', '50');
        url.searchParams.set('key', apiKey);
        if (options.publishedAfter) url.searchParams.set('publishedAfter', options.publishedAfter);
        if (options.publishedBefore) url.searchParams.set('publishedBefore', options.publishedBefore); // If you want to set an end time for the search
        if (pageToken) url.searchParams.set('pageToken', pageToken);

        const response = await fetch(url.href);
        const data = await response.json();

        if (response.status !== 200) {
            throw new Error(`API request failed with status ${response.status}: ${data.error.message}`);
        }

        data.items.forEach(item => {
            const {title, publishedAt} = item.snippet;
            const videoId = item.id.videoId;
            videos.push({
                title,
                videoId,
                publishedAt,
                url: `https://www.youtube.com/watch?v=${videoId}`
            });
        });
        await updateQuotaUsage(100);
        ; // Increment quota usage for each request
        pageToken = data.nextPageToken || '';
    } while (pageToken);


    //Order the videos by title
    videos.sort((a, b) => a.title.localeCompare(b.title));

    // Write the videos array to a JSON/CSV file
    if (formatChoice.format === 'CSV') {
        const csv = parse(videos); // Replace yourDataArray with the actual data array
        await fs.writeFile('output.csv', csv);
        console.log('Data saved as CSV');
    } else { // JSON is the default format
        await fs.writeFile('output.json', JSON.stringify(videos, null, 2)); // Replace yourDataArray with the actual data array
        console.log('Data saved as JSON');
    }
    console.log(`Fetched ${videos.length} videos from channel ID ${channelId} within the specified timeframe and saved to output file.`);
}


async function main() {
    const questions = [
        {
            type: 'list',
            name: 'task',
            message: 'Choose an operation:',
            choices: [
                {name: 'Fetch videos from a Playlist', value: 'fetchPlaylist'},
                {name: 'Obtain a Channel ID', value: 'fetchChannelId'},
                {name: 'Perform a General Channel Search', value: 'searchChannel'},
            ],
        },
    ];


    const {task} = await inquirer.prompt(questions);


    switch (task) {
        case 'fetchPlaylist': {
            const apiKey = await askForApiKey();
            const {playlistId} = await inquirer.prompt([
                {
                    type: 'input',
                    name: 'playlistId',
                    message: 'Enter the Playlist ID:',
                },
            ]);
            const formatChoice = await inquirer.prompt([
                {
                    type: 'list',
                    name: 'format',
                    message: 'Select the output format:',
                    choices: ['JSON', 'CSV'],
                },
            ]);

            await fetchVideos(apiKey, playlistId, formatChoice);
            break;
        }
        case 'fetchChannelId': {
            const apiKey = await askForApiKey();

            const {query} = await inquirer.prompt([
                {
                    type: 'input',
                    name: 'query',
                    message: 'Enter the channel name, username, etc.:',
                },
            ]);

            await fetchChannelId(apiKey, query);
            break;
        }
        case 'searchChannel': {
            const apiKey = await askForApiKey();

            const {channelId, publishedAfter} = await inquirer.prompt([
                {
                    type: 'input',
                    name: 'channelId',
                    message: 'Enter the Channel ID:',
                },
                {
                    type: 'input',
                    name: 'publishedAfter',
                    message: 'Enter the start date (e.g., 2/11/2024):',
                    validate: function (input) {
                        // Check if the input could be converted to a date
                        const date = new Date(input);
                        if (isNaN(date.getTime())) {
                            return `Sorry, I couldn't understand the date. Please enter it in either "2/11/2024" or "feb 11, 2024" format.`;
                        }

                        // If all checks pass, return true so the prompt knows the input is valid
                        return true;
                    },
                    filter: function (input) {
                        // Parse the date to the ISO 8601 format that you need
                        const date = new Date(input);
                        return date.toISOString();
                    }
                },
            ]);
            const formatChoice = await inquirer.prompt([
                {
                    type: 'list',
                    name: 'format',
                    message: 'Select the output format:',
                    choices: ['JSON', 'CSV'],
                },
            ]);

            await searchChannel(apiKey, channelId, {publishedAfter}, formatChoice);
            break;
        }
    }

}

async function askForApiKey() {
    const {apiKey} = await inquirer.prompt([
        {
            type: 'input',
            name: 'apiKey',
            message: 'Enter your API Key or press Enter to use the default:',
        },
    ]);
    return apiKey || defualtKey; // Use the default key if the user doesn't provide one
}

main().catch(error => console.error('An error occurred:', error));
